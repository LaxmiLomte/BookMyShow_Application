package com.rk.bookmyshow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rk.bookmyshow.entiry.Theatre;
import com.rk.bookmyshow.service.TheatreService;


@RestController
@RequestMapping("/theatre")
public class TheatreController {
@Autowired
private TheatreService theatreService;
	@PostMapping(value = "/add")
	public ResponseEntity<Theatre> addMovies(@RequestBody Theatre theatre){
		return new ResponseEntity<Theatre>(theatreService.addTheatre(theatre),HttpStatus.CREATED);
	}
}

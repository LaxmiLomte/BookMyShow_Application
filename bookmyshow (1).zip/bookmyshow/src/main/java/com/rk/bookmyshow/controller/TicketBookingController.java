package com.rk.bookmyshow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rk.bookmyshow.dto.BookingInfo;
import com.rk.bookmyshow.dto.TicketBooking;
import com.rk.bookmyshow.dto.TicketBookingRequest;
import com.rk.bookmyshow.service.TicketBookingService;

@RestController
public class TicketBookingController {
@Autowired
private TicketBookingService ticketBookingService;

@GetMapping("/info")
public ResponseEntity<BookingInfo> getInfo(){
	return new ResponseEntity<BookingInfo>(ticketBookingService.getInfo(),HttpStatus.OK);
	
}
@PostMapping("/bookmyshow")
public ResponseEntity<TicketBooking> bookTicket(@RequestBody TicketBookingRequest requst){
	return new ResponseEntity<TicketBooking>(ticketBookingService.bookTicket(requst),HttpStatus.CREATED);
}
}

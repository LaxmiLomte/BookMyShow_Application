package com.rk.bookmyshow.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rk.bookmyshow.entiry.City;
import com.rk.bookmyshow.service.CityService;

@RestController
@RequestMapping("/city")
public class CityController {
@Autowired
private CityService cityService;
	@PostMapping(value = "/add")
	public ResponseEntity<List<City>> addCity(@RequestBody List<City> cities){
		return new ResponseEntity<List<City>>(cityService.addCity(cities),HttpStatus.CREATED);
	}
}

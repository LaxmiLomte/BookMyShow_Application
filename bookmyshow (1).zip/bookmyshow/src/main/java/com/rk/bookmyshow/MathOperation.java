package com.rk.bookmyshow;

import java.util.Scanner;

class Addition{
	public int add(int a,int b) {
		return(a+b);
	}
}
public class MathOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Addition ad=new Addition();
Scanner sn=new Scanner(System.in);
System.out.println("enter first number:");
int a=sn.nextInt();
System.out.println("enter Second number:");
int b=sn.nextInt();
 int result=ad.add(a, b);
 System.out.println(result);
	}

}

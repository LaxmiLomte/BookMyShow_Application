package com.rk.bookmyshow.dto;

import java.util.List;

import com.rk.bookmyshow.entiry.City;
import com.rk.bookmyshow.entiry.Movie;
import com.rk.bookmyshow.entiry.Theatre;
import com.rk.bookmyshow.entiry.User;

public class BookingInfo {
	private List<User> users;
	private List<City> cities;
	private List<Movie>movies;
	private List<Theatre>theaters;
	public List<User> getUsers() {
		return users;
	}
	public void setUsers(List<User> users) {
		this.users = users;
	}
	public List<City> getCities() {
		return cities;
	}
	public void setCities(List<City> cities) {
		this.cities = cities;
	}
	public List<Movie> getMovies() {
		return movies;
	}
	public void setMovies(List<Movie> movies) {
		this.movies = movies;
	}
	public List<Theatre> getTheaters() {
		return theaters;
	}
	public void setTheaters(List<Theatre> theaters) {
		this.theaters = theaters;
	}
	@Override
	public String toString() {
		return "BookingInfo [" + (users != null ? "users=" + users + ", " : "")
				+ (cities != null ? "cities=" + cities + ", " : "") + (movies != null ? "movies=" + movies + ", " : "")
				+ (theaters != null ? "theaters=" + theaters : "") + "]";
	}
	public BookingInfo(List<User> users, List<City> cities, List<Movie> movies, List<Theatre> theaters) {
		super();
		this.users = users;
		this.cities = cities;
		this.movies = movies;
		this.theaters = theaters;
	}
	

}

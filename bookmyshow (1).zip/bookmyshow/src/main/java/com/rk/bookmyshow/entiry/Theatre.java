package com.rk.bookmyshow.entiry;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "my_theatre")
public class Theatre {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int theatreId;
	private String name;
	private String city;
	private String screens;
	private String shows;
	private double ticketPrice;
	
	public int getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(int theatreId) {
		this.theatreId = theatreId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getScreens() {
		return screens;
	}
	public void setScreens(String screens) {
		this.screens = screens;
	}
	public String getShows() {
		return shows;
	}
	public void setShows(String shows) {
		this.shows = shows;
	}
	public double getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	@Override
	public String toString() {
		return "Theatre [theatreId=" + theatreId + ", " + (name != null ? "name=" + name + ", " : "")
				+ (city != null ? "city=" + city + ", " : "") + (screens != null ? "screens=" + screens + ", " : "")
				+ (shows != null ? "shows=" + shows + ", " : "") + "ticketPrice=" + ticketPrice + "]";
	}
	
	

}

package com.rk.bookmyshow.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rk.bookmyshow.entiry.Theatre;
import com.rk.bookmyshow.repository.TheatreRepository;

@Service
public class TheatreService {
@Autowired
private TheatreRepository theatreRepository;

public Theatre addTheatre(Theatre theatre) {
	// TODO Auto-generated method stub
	return theatreRepository.save(theatre);
}




}

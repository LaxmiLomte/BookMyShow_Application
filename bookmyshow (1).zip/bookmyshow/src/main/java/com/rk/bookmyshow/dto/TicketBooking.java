package com.rk.bookmyshow.dto;

public class TicketBooking {
	private String movie;
	private String theatre;
	private double billamount;
	private int ticketCount;
	private String status;
	public String getMovie() {
		return movie;
	}
	public void setMovie(String movie) {
		this.movie = movie;
	}
	public String getTheatre() {
		return theatre;
	}
	public void setTheatre(String theatre) {
		this.theatre = theatre;
	}
	public double getBillamount() {
		return billamount;
	}
	public void setBillamount(double billamount) {
		this.billamount = billamount;
	}
	public int getTicketCount() {
		return ticketCount;
	}
	public void setTicketCount(int ticketCount) {
		this.ticketCount = ticketCount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "TicketBooking [" + (movie != null ? "movie=" + movie + ", " : "")
				+ (theatre != null ? "theatre=" + theatre + ", " : "") + "billamount=" + billamount + ", ticketCount="
				+ ticketCount + ", " + (status != null ? "status=" + status : "") + "]";
	}
	
}

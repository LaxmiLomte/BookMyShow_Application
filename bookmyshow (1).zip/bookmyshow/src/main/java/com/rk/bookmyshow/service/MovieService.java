package com.rk.bookmyshow.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rk.bookmyshow.entiry.Movie;
import com.rk.bookmyshow.repository.MovieRepository;

@Service
public class MovieService {
@Autowired
private MovieRepository movieRepository;



public List<Movie> addMovies(List<Movie> movies) {
	List<Movie> response=new ArrayList<Movie>();
	Movie mov=null;
	for(Movie m:movies) {
		mov=new Movie();
		mov=movieRepository.save(m);
		response.add(mov);
	}
		
	return response;
}
}

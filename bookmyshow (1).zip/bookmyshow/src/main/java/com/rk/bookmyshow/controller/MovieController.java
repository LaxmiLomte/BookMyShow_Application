package com.rk.bookmyshow.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rk.bookmyshow.entiry.Movie;
import com.rk.bookmyshow.service.MovieService;


@RestController
@RequestMapping("/movies")
public class MovieController {
@Autowired
private MovieService movieService;
	@PostMapping(value = "/add")
	public ResponseEntity<List<Movie>> addMovies(@RequestBody List<Movie> cities){
		return new ResponseEntity<List<Movie>>(movieService.addMovies(cities),HttpStatus.CREATED);
	}
}

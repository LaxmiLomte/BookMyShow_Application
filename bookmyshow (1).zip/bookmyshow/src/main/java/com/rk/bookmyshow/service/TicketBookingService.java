package com.rk.bookmyshow.service;

import java.time.LocalDateTime;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.rk.bookmyshow.dto.BookingInfo;
import com.rk.bookmyshow.dto.Payment;
import com.rk.bookmyshow.dto.PaymentRes;
import com.rk.bookmyshow.dto.TicketBooking;
import com.rk.bookmyshow.dto.TicketBookingRequest;
import com.rk.bookmyshow.entiry.User;
import com.rk.bookmyshow.repository.CityRepository;
import com.rk.bookmyshow.repository.MovieRepository;
import com.rk.bookmyshow.repository.TheatreRepository;
import com.rk.bookmyshow.repository.UserRepository;
@Service
public class TicketBookingService {
@Autowired
private UserRepository userRepository;
@Autowired
private MovieRepository movieRepository;
@Autowired 
private CityRepository cityRepository;
@Autowired
private TheatreRepository theatreRepository;
	public BookingInfo getInfo() {
		// TODO Auto-generated method stub
		BookingInfo info=new BookingInfo(userRepository.findAll(), cityRepository.findAll(), movieRepository.findAll(), theatreRepository.findAll());
		return info;
	}
	public TicketBooking bookTicket(TicketBookingRequest requst) {
		// TODO Auto-generated method stub
		User user=userRepository.findByEmailAndPassword(requst.getEmail(), requst.getPassword());
		RestTemplate restTemplate=new RestTemplate();
		TicketBooking booking=new TicketBooking();
		if(user!=null) {
			Payment paymet=new Payment();
			paymet.setAccNo(new Random().nextInt(10000000));
			paymet.setAccountHolderName(user.getName());
			paymet.setBalance(requst.getTicketamount()*requst.getTicketCount());
			paymet.setBankName("SBI");
			paymet.setTransId(new Random().nextInt(100000));
			paymet.setLocalDateTime(LocalDateTime.now());
			ResponseEntity<PaymentRes> res= restTemplate.postForEntity("http://localhost:9090/payment", paymet, PaymentRes.class);
			if(res.getBody()!=null&&res.getBody().getStatus().equalsIgnoreCase("success")) {
				booking.setBillamount(paymet.getBalance());
				booking.setMovie(requst.getMovie());
				booking.setStatus("Booked ticket");
				booking.setTheatre(requst.getTheatre());
				booking.setTicketCount(requst.getTicketCount());
			}
		}
		return booking;
	}

}

package com.rk.bookmyshow.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrowsExactly;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.springframework.boot.test.context.SpringBootTest;

import com.rk.bookmyshow.dto.UserRequest;
import com.rk.bookmyshow.dto.UserResponse;
import com.rk.bookmyshow.entiry.User;
import com.rk.bookmyshow.repository.UserRepository;

@SpringBootTest
public class RegisterTest {
	@InjectMocks
	private UserService userService;
	@Mock
	private UserRepository userRepository;
	@Mock
	private Logger logger;
	@Mock
	private User u;
	
	@Test
	public void addUserTest() {
		UserRequest request=new UserRequest();
		request.setAddress("pune");
		request.setAge(12);
		request.setEmail("test@mail.com");
		request.setName("test");
		UserResponse response=new UserResponse();
		User user=new User();
		user.setAddress("pune");
		user.setAge(12);
		user.setEmail("test@mail.com");
		user.setName("test");
		response.setResponse(user);
		response.setStatus("Fail to added user in database...!");;
		Mockito.when(userRepository.save(user)).thenReturn(user);
		UserResponse res=userService.addUser(request);
		assertNotNull(res);
	}
	@Test
	public void addUserTestException() {
		UserRequest request=new UserRequest();
		request.setAddress("pune");
		request.setAge(12);
		request.setEmail("test@mail.com");
		request.setName("test");
		UserResponse response=new UserResponse();
		User user=new User();
		user.setAddress("pune");
		user.setAge(12);
		user.setEmail("test@mail.com");
		user.setName("test");
		response.setResponse(user);
		response.setStatus("Fail to added user in database...!");;
		Mockito.when(userRepository.save(user)).thenThrow(Exception.class);
		//
		assertEquals(Exception.class, userService.addUser(request));
	}

}
